import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MsalModule, MsalService, MSAL_INSTANCE } from '@azure/msal-angular';
import {
  IPublicClientApplication,
  PublicClientApplication,
} from '@azure/msal-browser';
import { AuthGuard, coreModule, UserService } from '@ado-bcp-ui/core';
import { Config } from './constants/config';

export function MSALInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication({
    auth: {
      clientId: Config.CLIENTID,
      redirectUri: Config.REDIRECTURI,
    },
  });
}
@NgModule({
  imports: [CommonModule, MsalModule, coreModule],
  exports: [],
  declarations: [],
  providers: [
    {
      provide: MSAL_INSTANCE,
      useFactory: MSALInstanceFactory,
    },
    MsalService,
    UserService,
    AuthGuard,
  ],
})
export class LoginModule {}
