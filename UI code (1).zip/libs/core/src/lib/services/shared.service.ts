/* eslint-disable @nrwl/nx/enforce-module-boundaries */

import { Injectable } from '@angular/core';
import { map, Observable, ReplaySubject, Subject } from 'rxjs';
import {
  ApiService,
  ImenuElement,
  InotificationElement,
  IpopupElement,
  ItileElement,
  environment,
  ICreateOnScheduleBackup,
  ICreateOnDemandBackup,
  IProjects,
  IRepository,
  IRepoSubentity,
  IMinute,
  IEntity,
  IEvery,
  IHour,
  INoon,
  IDays,
  IPeriod,
  ITile,
  IBackup,
  IRestore,
} from '@ado-bcp-ui/core';

import {
  HttpClient,
  HttpEvent,
  HttpParams,
  HttpResponse,
} from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  public _SProject_Data = new Subject<any>();
  public _STile_Data = new Subject<any>();
  public _SBackup_Data = new Subject<any>();
  public _SRestore_Data = new Subject<any>();
  public _SEntity_Data = new Subject<any>();
  public _SSubEntity_Data = new Subject<any>();
  public _SRepository_Data = new Subject<any>();
  public _SMessage = new ReplaySubject<any>();

  constructor(private apiService: ApiService, private http: HttpClient) {}

  //BackupMethod
  createOnDemandBackup(paramsOnDemand: ICreateOnDemandBackup): Observable<any> {
    return this.apiService.post(`${environment.api_url}`, paramsOnDemand).pipe(
      map((data) => {
        return data;
      })
    );
  }
  createOnScheduleBackup(
    paramsSchedule: ICreateOnScheduleBackup
  ): Observable<any> {
    return this.apiService.post(`${environment.api_url}`, paramsSchedule).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getProjectDetails(organizationName: string): Observable<IProjects> {
    const params = new HttpParams().set('organizationName', organizationName);
    return this.apiService
      .get(`${environment.api_url}/ddlProjectData`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getEntityDetails(): Observable<IEntity> {
    return this.apiService.get(`${environment.api_url}/ddlEntityData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getMinuteDetails(): Observable<IMinute> {
    return this.apiService.get(`${environment.api_url}/ddlMinuteData`).pipe(
      map((data) => {
        return data;
      })
    );
  }
  getRepositoryDetails(
    repositoryDetails: IRepository
  ): Observable<IRepository> {
    const params = new HttpParams()
      .set('RepositoryDetails', repositoryDetails.organizationName)
      .set('projectName', repositoryDetails.projectName);
    return this.apiService
      .get(`${environment.api_url}/ddlRepositoryData`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getRepoSubentityDetails(): Observable<IRepoSubentity> {
    return this.apiService
      .get(`${environment.api_url}/ddlRepoSubentityData`)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getEveryDetails(): Observable<IEvery> {
    return this.apiService.get(`${environment.api_url}/ddlEveryData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getHourDetails(): Observable<IHour> {
    return this.apiService.get(`${environment.api_url}/ddlHourData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getNoonDetails(): Observable<INoon> {
    return this.apiService.get(`${environment.api_url}/ddlNoonData`).pipe(
      map((data) => {
        return data;
      })
    );
  }
  getDaysDetails(): Observable<IDays> {
    return this.apiService.get(`${environment.api_url}/ddlDaysData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getNotificationDetails(): Observable<InotificationElement> {
    return this.apiService.get(`${environment.api_url}/notifications`).pipe(
      map((data) => {
        return data;
      })
    );
  }
  getBackupPopupDetails(): Observable<IpopupElement> {
    return this.apiService.get(`${environment.api_url}/popupTitle`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getMenuDetails(): Observable<ImenuElement> {
    return this.apiService.get(`${environment.api_url}/menuElement`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getDashboardTileDetails(): Observable<ItileElement> {
    return this.apiService.get(`${environment.api_url}/titleData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getPeriodsDetails(): Observable<IPeriod> {
    return this.apiService.get(`${environment.api_url}/ddlPeriodData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getBackupDetails() {
    return this.apiService.get(`${environment.api_url}/getBackupDetails`).pipe(
      map((data) => {
        return data;
      })
    );
  }
  getViewBackup() {
    return this.apiService.get(`${environment.api_url}/viewData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getLabelDetails() {
    return this.apiService.get(`${environment.api_url}/labelData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getButtonDetails() {
    return this.apiService.get(`${environment.api_url}/buttonData`).pipe(
      map((data) => {
        return data;
      })
    );
  }
  titleDataProjectCopy(): Observable<ITile> {
    return this.apiService
      .get(`${environment.api_url}/titleDataProjectCopy`)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getBackupDetailsCopy(): Observable<IBackup> {
    return this.apiService
      .get(`${environment.api_url}/getBackupDetailsCopy`)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getRestoreDetailsCopy(): Observable<IRestore> {
    return this.apiService
      .get(`${environment.api_url}/getRestoreDetailsCopy`)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }
}
