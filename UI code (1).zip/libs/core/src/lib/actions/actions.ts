export const PROJECT = 'PROJECT';
export const ENTITY = 'ENTITY';
export const REPOSITORY = 'REPOSITORY';
export const SUB_ENTITY = 'SUB_ENTITY';
