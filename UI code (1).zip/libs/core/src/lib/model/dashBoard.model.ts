interface IcolumnElement {
  entity: string;
  subentity: string;
  initiatedAt: string;
  completedAt: string;
  status: string;
  action: string;
}

interface ItileElement {
  id: number;
  status: string;
  BackupCount: number;
  RestoreCount: number;
}

interface IpopupElement {
  title: string;
  contentElement: string[];
}

interface ICreateOnDemandBackup {
  repoId: string;
  organizationName: string;
  projectName: string;
}
interface ICreateOnScheduleBackup {
  repoId: string;
  organizationName: string;
  projectName: string;
  cronExpression: string;
}

interface IProjects {
  projectid: string;
  projectname: string;
  organizationname: string;
  criticality: string;
  isative: number;
  entitySettingsDetails: [];
  entityTransactionDetails: [];
}

interface IRepoSubentity {
  subentityid: number;
  entityid: number;
  name: string;
  order: number;
  parentid: number;
}

interface IRepository {
  organizationName: string;
  projectName: string;
}

interface IMinute {
  key: string;
  value: string;
}
interface IEntity {
  id: number;
  name: string;
}
interface IEvery {
  key: string;
  value: string;
}
interface IHour {
  key: string;
  value: string;
}
interface INoon {
  key: string;
  value: string;
}
interface IDays {
  key: string;
  value: string;
}
interface IPeriod {
  key: string;
  value: string;
}

interface ITile {
  id: number;
  status: string;
  BackupCount: number;
  RestoreCount: number;
  class: string;
}
interface IBackup {
  Entity: string;
  Subentity: string;
  InitiatedAt: string;
  CompletedAt: string;
  Status: string;
  Action: string;
}
interface IRestore {
  Entity: string;
  Subentity: string;
  InitiatedAt: string;
  CompletedAt: string;
  Status: string;
  Action: string;
}
export {
  IcolumnElement,
  ItileElement,
  IpopupElement,
  ICreateOnDemandBackup,
  ICreateOnScheduleBackup,
  IProjects,
  IRepository,
  IRepoSubentity,
  IMinute,
  IEntity,
  IEvery,
  IHour,
  INoon,
  IDays,
  IPeriod,
  ITile,
  IBackup,
  IRestore,
};
