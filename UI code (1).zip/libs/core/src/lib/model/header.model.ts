interface InotificationElement {
  title: string;
  subTitle: string;
}

interface Iuser {
  email: string;
  token: string;
  username: string;
  bio: string;
  image: string;
}

export { InotificationElement, Iuser };
