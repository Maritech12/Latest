interface IsubMenuElement {
  routerLink: string;
  icon: string;
  title: string;
}

interface ImenuElement {
  routerLink: string;
  icon: string;
  title: string;
  submenu: IsubMenuElement[];
}


enum Days {
  Sunday = 'S',
  Monday = 'M',
  Tuesday = 'T',
  Wednesday = 'W',
  Thursday = 'TH',
  Friday = 'F',
  Saturday = 'SA',
}

export {
  ImenuElement
};
