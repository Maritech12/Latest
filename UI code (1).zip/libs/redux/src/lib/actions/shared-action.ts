import { Action } from '@ngrx/store';
import { Shared } from '../store/shared';

export const SHAREDACT = 'SHAREDACT';
export const DASHBOARD = 'DASHBOARD';

export class SharedAction implements Action {
  type: string = DASHBOARD;

  constructor(public sharedState: Shared) {}
}
