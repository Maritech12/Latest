import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { sharedReducer } from './reducers/shared-reducer';
import { StoreModule } from '@ngrx/store';
@NgModule({
  imports: [CommonModule,
  StoreModule.forRoot({ projectDetails: sharedReducer })]
})
export class ReduxModule {}
