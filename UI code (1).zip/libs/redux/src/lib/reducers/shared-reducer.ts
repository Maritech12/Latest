import { Action, INIT } from '@ngrx/store';
import { DASHBOARD, SharedAction } from '../actions/shared-action';
import { Shared } from '../store/shared';

//const initialState: Shared [] = [{projectDetails:[{ project: "",entity: "",repository:"",subEntity: ""}]}]
const initialState: Shared[] = [];
export function sharedReducer(state: Shared[] = [], action: Action): Shared[] {
  switch (action.type) {
    case DASHBOARD:
      return [(action as SharedAction).sharedState];
    case INIT:
      return initialState;
    default:
      throw Error(`The action type "${action.type}" is not implemented`);
  }
}
