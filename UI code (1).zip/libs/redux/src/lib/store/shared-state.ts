import { Shared } from './shared';

export interface SharedState {
  projectDetails: Shared[];
}
