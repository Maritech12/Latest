// export interface Shared {
//   projectDetails: IsubElement[];
// }

// interface IsubElement {
//   project: '';
//   entity: '';
//   repository: '';
//   subEntity: '';
// }

export interface Shared {
  projectDetails: [];
}
