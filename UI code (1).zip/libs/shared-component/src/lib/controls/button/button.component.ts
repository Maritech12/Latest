import { SharedService } from '@ado-bcp-ui/core';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
})
export class ButtonComponent implements OnInit {
buttonData : any ;
@Input() ddlElementData:any;
  constructor(private sharedService: SharedService ) {}

  ngOnInit(): void {
  }
}
