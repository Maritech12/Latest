import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatSelect } from '@angular/material/select';
declare var $: any;
@Component({
  selector: 'ado-bcp-ui-multi-select',
  templateUrl: './multi-select.component.html',
  styleUrls: ['./multi-select.component.scss'],
})
export class MultiSelectComponent implements OnInit {
  @Input() ddlElement: any;
  @Input() ddlElementType: any;
  selectedOption = 'option0';
  public modeselect = 'Select';
  selectedMulti!: any[];
  @Output() ddlOnChanged: EventEmitter<any> = new EventEmitter<any>();
  @Output() ddlOnSelectAll: EventEmitter<any> = new EventEmitter<any>();
  @Output() ddlOnSelectClick: EventEmitter<any> = new EventEmitter<any>();
  

  constructor() {}
  ngOnInit(): void {}

  selectAll(select: MatSelect, values: any, array: any) {
    select.value = values;
    //array = values;
  }

  deselectAll(select: MatSelect) {
    select.value = [];
  }

  ok(select: MatSelect) {
    $('#multiSelect').modal('show');
  }
  cancel(select: MatSelect) {
    select.value = [];
    $('#multiSelect').modal('hide');
  }
}
