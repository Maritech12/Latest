/* eslint-disable @typescript-eslint/no-inferrable-types */
import { SharedService } from '@ado-bcp-ui/core';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-popup-layout',
  templateUrl: './popup-layout.component.html',
  styleUrls: ['./popup-layout.component.scss'],
})
export class PopupLayoutComponent implements OnInit {
  constructor(private sharedService: SharedService) {}

  popupTitleElement: any = [];
  ngOnInit(): void {
    this.sharedService.getBackupPopupDetails().subscribe((data) => {
      this.popupTitleElement = data;
    });
  }
}
