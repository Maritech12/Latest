/* eslint-disable @nrwl/nx/enforce-module-boundaries */
import { Component, Input, OnInit } from '@angular/core';
// eslint-disable-next-line @nrwl/nx/enforce-module-boundaries
import { SharedService } from '@ado-bcp-ui/core';
@Component({
  selector: 'ado-bcp-ui-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
})
export class NotificationComponent implements OnInit {
  notificationMessage!: string;
  notificationContent!: string;
  notificationElement: any = [];

  constructor(private sharedService: SharedService) {}

  ngOnInit(): void {
    this.sharedService.getNotificationDetails().subscribe((data) => {
      this.notificationElement = data;
      this.notificationMessage =
        this.notificationElement.length+' Notification(s)';
      this.notificationContent = 'Show all notifications';
    });
  }
}
