import {
  environment,
  ICreateOnDemandBackup,
  ICreateOnScheduleBackup,
  IDays,
  IEntity,
  IEvery,
  IHour,
  IMinute,
  INoon,
  IProjects,
  IRepository,
  IRepoSubentity,
  SharedService,
} from '@ado-bcp-ui/core';
import { Component, ElementRef, OnInit } from '@angular/core';
import { MatSelect } from '@angular/material/select';
@Component({
  selector: 'ado-bcp-ui-model-popup',
  templateUrl: './model-popup.component.html',
  styleUrls: ['./model-popup.component.scss'],
})
export class ModelPopupComponent implements OnInit {
  selectedMulti!: any[];

  ddlProjectData: IProjects = {
    projectid: '',
    projectname: '',
    organizationname: '',
    criticality: '',
    isative: 0,
    entitySettingsDetails: [],
    entityTransactionDetails: [],
  };
  params: ICreateOnDemandBackup = {
    repoId: '',
    organizationName: '',
    projectName: '',
  };
  paramsSchedule: ICreateOnScheduleBackup = {
    repoId: '',
    organizationName: '',
    projectName: '',
    cronExpression: '',
  };
  //ddlRepositoryData: any;
  ddlRepositoryData: IRepository = {
    organizationName: '',
    projectName: '',
  };
  projectData: any = [];
  ddlEntityData: IEntity = {
    id: 0,
    name: '',
  };
  ddlRepoSubentityData: IRepoSubentity = {
    subentityid: 0,
    entityid: 0,
    name: '',
    order: 0,
    parentid: 0,
  };
  ddlWorkitemSubentityData: any;
  ddlEveryData: IEvery = {
    key: '',
    value: '',
  };
  ddlHourData: IHour = {
    key: '',
    value: '',
  };
  ddlMinuteData: IMinute = {
    key: '',
    value: '',
  };
  ddlNoonData: INoon = {
    key: '',
    value: '',
  };
  ddlDaysData: IDays = {
    key: '',
    value: '',
  };
  ddlButtonData: any;
  labelData: any;
  entityData: any;
  SubEntityData: any;
  sharedDetails: any;
  //hiding info
  visibleSchedule: boolean = false;
  entityDisabled: boolean = true;
  repoSubEntityDisable: boolean = false;

  onDemandBackupDetails: any;
  onScheduleBackupDetails: any;

  scheduleAction: any;
  scheduler: any = {
    every: 'Daily',
    repatOn: '',
    time: '',
    week: '',
  };

  backupDetails: any = {
    project: '',
    entity: '',
  };
  entityDetails: any;
  ddlSelected: any = '1';
  ddlSelEntity: any = '2';
  paramsRepo: IRepository = {
    organizationName: '',
    projectName: '',
  };
  checkactive: boolean = false;

  options = ['Option 1', 'Option 2', 'Option 3', 'Option 4', 'Option 5'];
  years = [
    { id: 1, viewValue: '2017' },
    { id: 2, viewValue: '2018' },
    { id: 3, viewValue: '2019' },
    { id: 4, viewValue: '2020' },
    { id: 5, viewValue: '2021' },
  ];
  selected = [];
  constructor(private sharedService: SharedService) {}
  ngOnInit(): void {
    this.paramsRepo.organizationName = environment.organizationName;
    this.paramsRepo.projectName = this.params.projectName;

    this.sharedService
      .getProjectDetails(this.paramsRepo.organizationName)
      .subscribe((data: IProjects) => {
        this.ddlProjectData = data;
      });

    this.sharedService.getEntityDetails().subscribe((data: IEntity) => {
      this.ddlEntityData = data;
    });

    this.sharedService
      .getRepositoryDetails(this.paramsRepo)
      .subscribe((data: IRepository) => {
        this.ddlRepositoryData = data;
      });
    this.sharedService
      .getRepoSubentityDetails()
      .subscribe((data: IRepoSubentity) => {
        this.ddlRepoSubentityData = data;
      });

    this.sharedService.getEveryDetails().subscribe((data: IEvery) => {
      this.ddlEveryData = data;
    });
    this.sharedService.getHourDetails().subscribe((data: IHour) => {
      this.ddlHourData = data;
    });
    this.sharedService.getMinuteDetails().subscribe((data: IMinute) => {
      this.ddlMinuteData = data;
    });
    this.sharedService.getNoonDetails().subscribe((data: INoon) => {
      this.ddlNoonData = data;
    });
    this.sharedService.getDaysDetails().subscribe((data: IDays) => {
      this.ddlDaysData = data;
    });
  }

  //onclick toggling both
  onclick(val: any) {
    this.scheduleAction = val.target.checked;
    this.visibleSchedule = !this.visibleSchedule;
  }

  selectProject(event: any) {
    this.params.projectName = event.target.innerText;
    this.ddlSelEntity = '1';
  }

  selectEntity(event: any) {
    this.entityDetails = event.currentTarget.id;
    this.repoSubEntityDisable = true;
  }

  selectRepository(event: any) {
    this.params.repoId = event.target.innerText;
  }

  selectSubEntity(event: any) {}

  selectEvery(event: any) {
    this.scheduler.every = event.target.innerText;
  }

  selectHour(event: any) {}
  selectMinute(event: any) {}
  selectNoon(event: any) {}
  selectDays(event: any) {
    alert();

    this.checkactive = !this.checkactive;
  }

  createOnDemandBackup() {
    //save method for OnDemandBackup...
    this.params.organizationName = this.paramsRepo.organizationName;
    this.sharedService.createOnDemandBackup(this.params).subscribe({
      next: (succ: any) => {
        if (succ.code == 200) {
          this.onDemandBackupDetails = succ.data;
          console.log('onDemandDetails', this.onDemandBackupDetails);
        }
      },
      error: (err) => {},
    });

    //save method for OnScheduleBackup...
    this.sharedService.createOnScheduleBackup(this.paramsSchedule).subscribe(
      (succ: any) => {
        if (succ.code == 200) {
          this.onScheduleBackupDetails = succ.data;
        }
      },
      (err) => {}
    );
  }

  cancel() {
    this.params = { repoId: '', organizationName: '', projectName: '' };
    this.scheduler = { every: 'Daily', repatOn: '', time: '', week: '' };
  }

  // selectAll(select: MatSelect, values: any, array: any) {
  //   select.value = values;
  //   array = values;
  // }

  selectClick(select: any) {
    //select.value =;
    //array = values;
  }

  deselectAll(select: MatSelect) {
    select.value = [];
  }
}
