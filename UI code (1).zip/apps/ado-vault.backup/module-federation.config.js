module.exports = {
  name: 'ado-vault.backup',
  exposes: {
    './Module': 'apps/ado-vault.backup/src/app/remote-entry/entry.module.ts',
  },
};
