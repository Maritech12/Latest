import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModelPopupComponent } from '@ado-bcp-ui/shared-component';
import { BackupService } from '../service/backup.service';
import { MediaMatcher } from '@angular/cdk/layout';
import {
  environment,
  ICreateOnDemandBackup,
  IPeriod,
  IProjects,
  SharedService,
} from '@ado-bcp-ui/core';

@Component({
  selector: 'ado-bcp-ui-backup',
  templateUrl: './backup.component.html',
  styleUrls: ['./backup.component.scss'],
})
export class BackupComponent implements OnInit, OnDestroy {
  mobileQuery: MediaQueryList;
  ddlProjectData: IProjects = {
    projectid: '',
    projectname: '',
    organizationname: '',
    criticality: '',
    isative: 0,
    entitySettingsDetails: [],
    entityTransactionDetails: [],
  };
  ddlPeriodData: IPeriod = {
    key: '',
    value: '',
  };
  params: ICreateOnDemandBackup = {
    repoId: '',
    organizationName: '',
    projectName: '',
  };
  private _mobileQueryListener: () => void;

  constructor(
    public dialog: MatDialog,
    private backupService: BackupService,
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    private sharedService: SharedService
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnInit(): void {
    this.sharedService
      .getProjectDetails(environment.organizationName)
      .subscribe((data: IProjects) => {
        this.ddlProjectData = data;
      });

    this.sharedService.getPeriodsDetails().subscribe((data: IPeriod) => {
      this.ddlPeriodData = data;
    });
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  openDialog() {
    const dialogRef = this.dialog.open(ModelPopupComponent);
    dialogRef.afterClosed().subscribe((result) => {
      console.log(`Dialog result: ${result}`);
    });
  }
}
