export class EntityModel {}
