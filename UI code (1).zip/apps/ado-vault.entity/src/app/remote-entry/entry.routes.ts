import { Route } from '@angular/router';
import { EntityComponent } from '../components/entity.component';


export const remoteRoutes: Route[] = [{ path: '', component: EntityComponent }];
