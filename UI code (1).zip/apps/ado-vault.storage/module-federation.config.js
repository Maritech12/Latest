module.exports = {
  name: 'ado-vault.storage',
  exposes: {
    './Module': 'apps/ado-vault.storage/src/app/remote-entry/entry.module.ts',
  },
};
