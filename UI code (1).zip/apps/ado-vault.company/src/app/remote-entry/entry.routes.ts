import { Route } from '@angular/router';
import { CompanyComponent } from '../components/company.component';

export const remoteRoutes: Route[] = [
  { path: '', component: CompanyComponent },
];
