import { Route } from '@angular/router';
import { RoleComponent } from '../components/role/role.component';

export const remoteRoutes: Route[] = [
  { path: '', component: RoleComponent },
];
