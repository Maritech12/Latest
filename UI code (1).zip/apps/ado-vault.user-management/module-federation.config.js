module.exports = {
  name: 'ado-vault.user-management',
  exposes: {
    './Module':
      'apps/ado-vault.user-management/src/app/remote-entry/entry.module.ts',
  },
};
