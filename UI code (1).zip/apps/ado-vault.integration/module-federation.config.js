module.exports = {
  name: 'ado-vault.integration',
  exposes: {
    './Module':
      'apps/ado-vault.integration/src/app/remote-entry/entry.module.ts',
  },
};
