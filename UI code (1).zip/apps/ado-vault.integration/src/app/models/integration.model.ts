export class IntegrationModel {}
