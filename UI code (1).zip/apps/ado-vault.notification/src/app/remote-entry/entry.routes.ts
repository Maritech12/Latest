import { Route } from '@angular/router';
import { NotificationComponent } from '../components/notification.component';

export const remoteRoutes: Route[] = [
  { path: '', component: NotificationComponent },
];
